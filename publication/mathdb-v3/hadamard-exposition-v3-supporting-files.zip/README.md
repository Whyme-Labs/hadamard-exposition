# Hadamard exposition v3: supporting files

This archive accompanies the PDF "What the Hadamard conjecture promises", version 3.
Run the commands in the article's "Reproduce and inspect" section from this directory.

- submission/v3: the frozen v3 edition (manuscript, PDF, HTML, checks, checksums).
- submission/v2: the unchanged v2 evidence used by Part III (study data, audit, checkers).

Each edition has its own SHA256SUMS. Text and data: CC BY 4.0. Code: MIT.
